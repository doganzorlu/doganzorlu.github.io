#include <linux/module.h>
#define INCLUDE_VERMAGIC
#include <linux/build-salt.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

BUILD_SALT;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif

static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0xcea15aad, "module_layout" },
	{ 0x4b6dbab9, "cdev_del" },
	{ 0x3422c712, "class_destroy" },
	{ 0x576a3eca, "device_destroy" },
	{ 0xd7ef4697, "device_create" },
	{ 0x41c03874, "__class_create" },
	{ 0x6091b333, "unregister_chrdev_region" },
	{ 0x2c7b3e8c, "cdev_add" },
	{ 0xcaf4ced0, "cdev_init" },
	{ 0xc5850110, "printk" },
	{ 0xe3ec2f2b, "alloc_chrdev_region" },
	{ 0xcbd4898c, "fortify_panic" },
	{ 0xa916b694, "strnlen" },
	{ 0xe6e4efc9, "uniwill_get_active_interface_id" },
	{ 0x88db9f48, "__check_object_size" },
	{ 0x754d539c, "strlen" },
	{ 0x118769a1, "clevo_get_active_interface_id" },
	{ 0x13c49cc2, "_copy_from_user" },
	{ 0x6b10bee1, "_copy_to_user" },
	{ 0x8ec36e32, "clevo_evaluate_method" },
	{ 0xc959d152, "__stack_chk_fail" },
	{ 0x837b7b09, "__dynamic_pr_debug" },
	{ 0xf9a482f9, "msleep" },
	{ 0x752c9bd9, "uniwill_write_ec_ram" },
	{ 0xa4b433b1, "uniwill_read_ec_ram" },
	{ 0xbdfb6dbb, "__fentry__" },
	{ 0x56470118, "__warn_printk" },
};

MODULE_INFO(depends, "delidumrul_keyboard");


MODULE_INFO(srcversion, "3424D04D978D29A8484AB12");
