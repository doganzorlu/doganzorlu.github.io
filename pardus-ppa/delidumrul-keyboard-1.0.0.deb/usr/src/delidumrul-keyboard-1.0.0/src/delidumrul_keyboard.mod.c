#include <linux/module.h>
#define INCLUDE_VERMAGIC
#include <linux/build-salt.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

BUILD_SALT;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif

static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0xcea15aad, "module_layout" },
	{ 0x2d3385d3, "system_wq" },
	{ 0x3b7a9437, "device_remove_file" },
	{ 0xeb233a45, "__kmalloc" },
	{ 0xf9a482f9, "msleep" },
	{ 0x525a078c, "param_get_int" },
	{ 0x2b68bd2f, "del_timer" },
	{ 0x754d539c, "strlen" },
	{ 0x837b7b09, "__dynamic_pr_debug" },
	{ 0x39eb59d, "param_ops_bool" },
	{ 0xc6f46339, "init_timer_key" },
	{ 0x409bcb62, "mutex_unlock" },
	{ 0x221f6a1c, "param_set_int" },
	{ 0x78ddb76b, "dmi_match" },
	{ 0x96554810, "register_keyboard_notifier" },
	{ 0x3c3ff9fd, "sprintf" },
	{ 0x337f5ce2, "sysfs_remove_group" },
	{ 0x15ba50a6, "jiffies" },
	{ 0xe2d5255a, "strcmp" },
	{ 0x52fd1974, "param_ops_string" },
	{ 0x511b8681, "sparse_keymap_setup" },
	{ 0xfba6632b, "input_event" },
	{ 0x9ed554b3, "unregister_keyboard_notifier" },
	{ 0xc5850110, "printk" },
	{ 0x232007aa, "led_classdev_register_ext" },
	{ 0x36ee7ef7, "sysfs_create_group" },
	{ 0x2ab7989d, "mutex_lock" },
	{ 0x1e6d26a8, "strstr" },
	{ 0xc38c83b8, "mod_timer" },
	{ 0x8dd0f7b5, "platform_device_unregister" },
	{ 0x8c8569cb, "kstrtoint" },
	{ 0xd22f0cf8, "device_create_file" },
	{ 0xc959d152, "__stack_chk_fail" },
	{ 0xb209eb94, "input_register_device" },
	{ 0x8985f06c, "__platform_create_bundle" },
	{ 0x35d45e91, "input_free_device" },
	{ 0x2ea2c95c, "__x86_indirect_thunk_rax" },
	{ 0xbdfb6dbb, "__fentry__" },
	{ 0x3e176aed, "led_classdev_unregister" },
	{ 0x37a0cba, "kfree" },
	{ 0x3b6c41ea, "kstrtouint" },
	{ 0xcd1b3773, "input_unregister_device" },
	{ 0xa288213f, "sparse_keymap_report_entry" },
	{ 0xc5b6f236, "queue_work_on" },
	{ 0xcbea820c, "platform_driver_unregister" },
	{ 0x77bc13a0, "strim" },
	{ 0x77ec53bd, "param_ops_uint" },
	{ 0xcaef59f1, "sparse_keymap_entry_from_scancode" },
	{ 0xe914e41e, "strcpy" },
	{ 0xbd3fd762, "input_allocate_device" },
	{ 0x81e6b37f, "dmi_get_system_info" },
};

MODULE_INFO(depends, "sparse-keymap");


MODULE_INFO(srcversion, "CA493887B3380E4D3012FFC");
