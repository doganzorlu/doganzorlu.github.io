/*!
 * Copyright (c) 2018-2020 DELIDUMRUL Notebook <info@delidumrulnotebook.com.tr>
 *
 * This file is part of delidumrul-keyboard.
 *
 * delidumrul-keyboard is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this software.  If not, see <https://www.gnu.org/licenses/>.
 */
#define pr_fmt(fmt) "delidumrul_keyboard" ": " fmt

#include "delidumrul_keyboard_common.h"
#include "clevo_keyboard.h"
#include "uniwill_keyboard.h"
#include <linux/mutex.h>

MODULE_AUTHOR("DELIDUMRUL Notebook <info@delidumrulnotebook.com.tr>");
MODULE_DESCRIPTION("Keyboard & keyboard backlight driver for DELIDUMRUL notebooks");
MODULE_LICENSE("GPL");
MODULE_VERSION("1.0.0");

static DEFINE_MUTEX(delidumrul_keyboard_init_driver_lock);

// static struct delidumrul_keyboard_driver *driver_list[] = { };

static int delidumrul_input_init(const struct key_entry key_map[])
{
	int err;

	delidumrul_input_device = input_allocate_device();
	if (unlikely(!delidumrul_input_device)) {
		DELIDUMRUL_ERROR("Error allocating input device\n");
		return -ENOMEM;
	}

	delidumrul_input_device->name = "DELIDUMRUL Keyboard";
	delidumrul_input_device->phys = DRIVER_NAME "/input0";
	delidumrul_input_device->id.bustype = BUS_HOST;
	delidumrul_input_device->dev.parent = &delidumrul_platform_device->dev;

	if (key_map != NULL) {
		err = sparse_keymap_setup(delidumrul_input_device, key_map, NULL);
		if (err) {
			DELIDUMRUL_ERROR("Failed to setup sparse keymap\n");
			goto err_free_input_device;
		}
	}

	err = input_register_device(delidumrul_input_device);
	if (unlikely(err)) {
		DELIDUMRUL_ERROR("Error registering input device\n");
		goto err_free_input_device;
	}

	return 0;

err_free_input_device:
	input_free_device(delidumrul_input_device);

	return err;
}

struct platform_device *delidumrul_keyboard_init_driver(struct delidumrul_keyboard_driver *tk_driver)
{
	int err;
	struct platform_device *new_platform_device = NULL;

	DELIDUMRUL_DEBUG("init driver start\n");

	mutex_lock(&delidumrul_keyboard_init_driver_lock);

	if (!IS_ERR_OR_NULL(delidumrul_platform_device)) {
		// If already initialized, don't proceed
		DELIDUMRUL_DEBUG("platform device already initialized\n");
		goto init_driver_exit;
	} else {
		// Otherwise, attempt to initialize structures
		DELIDUMRUL_DEBUG("create platform bundle\n");
		new_platform_device = platform_create_bundle(
			tk_driver->platform_driver, tk_driver->probe, NULL, 0, NULL, 0);

		delidumrul_platform_device = new_platform_device;

		if (IS_ERR_OR_NULL(delidumrul_platform_device)) {
			// Normal case probe failed, no init
			goto init_driver_exit;
		}

		DELIDUMRUL_DEBUG("initialize input device\n");
		if (tk_driver->key_map != NULL) {
			err = delidumrul_input_init(tk_driver->key_map);
			if (unlikely(err)) {
				DELIDUMRUL_ERROR("Could not register input device\n");
				tk_driver->input_device = NULL;
			} else {
				DELIDUMRUL_DEBUG("input device registered\n");
				tk_driver->input_device = delidumrul_input_device;
			}
		}

		current_driver = tk_driver;
	}

init_driver_exit:
	mutex_unlock(&delidumrul_keyboard_init_driver_lock);
	return new_platform_device;
}
EXPORT_SYMBOL(delidumrul_keyboard_init_driver);

static void __exit delidumrul_input_exit(void)
{
	if (unlikely(!delidumrul_input_device)) {
		return;
	}

	input_unregister_device(delidumrul_input_device);
	{
		delidumrul_input_device = NULL;
	}
}

void delidumrul_keyboard_remove_driver(struct delidumrul_keyboard_driver *tk_driver)
{
	bool specified_driver_differ_from_used =
		tk_driver != NULL && 
		(
			strcmp(
				tk_driver->platform_driver->driver.name,
				current_driver->platform_driver->driver.name
			) != 0
		);

	if (specified_driver_differ_from_used)
		return;

	DELIDUMRUL_DEBUG("delidumrul_input_exit()\n");
	delidumrul_input_exit();
	DELIDUMRUL_DEBUG("platform_device_unregister()\n");
	if (!IS_ERR_OR_NULL(delidumrul_platform_device)) {
		platform_device_unregister(delidumrul_platform_device);
		delidumrul_platform_device = NULL;
	}
	DELIDUMRUL_DEBUG("platform_driver_unregister()\n");
	if (!IS_ERR_OR_NULL(current_driver)) {
		platform_driver_unregister(current_driver->platform_driver);
		current_driver = NULL;
	}

}
EXPORT_SYMBOL(delidumrul_keyboard_remove_driver);

static int __init delidumrul_keyboard_init(void)
{
	DELIDUMRUL_INFO("module init\n");
	return 0;
}

static void __exit delidumrul_keyboard_exit(void)
{
	DELIDUMRUL_INFO("module exit\n");

	if (delidumrul_platform_device != NULL)
		delidumrul_keyboard_remove_driver(NULL);
}

module_init(delidumrul_keyboard_init);
module_exit(delidumrul_keyboard_exit);
