/*!
 * Copyright (c) 2018-2020 MONSTER Notebook <info@monsternotebook.com.tr>
 *
 * This file is part of monster-keyboard.
 *
 * monster-keyboard is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this software.  If not, see <https://www.gnu.org/licenses/>.
 */
#define pr_fmt(fmt) "monster_keyboard" ": " fmt

#include "monster_keyboard_common.h"
#include "clevo_keyboard.h"
#include "uniwill_keyboard.h"
#include <linux/mutex.h>

MODULE_AUTHOR("MONSTER Notebook <info@monsternotebook.com.tr>");
MODULE_DESCRIPTION("Keyboard & keyboard backlight driver for MONSTER notebooks");
MODULE_LICENSE("GPL");
MODULE_VERSION("3.0.10");

static DEFINE_MUTEX(monster_keyboard_init_driver_lock);

// static struct monster_keyboard_driver *driver_list[] = { };

static int monster_input_init(const struct key_entry key_map[])
{
	int err;

	monster_input_device = input_allocate_device();
	if (unlikely(!monster_input_device)) {
		MONSTER_ERROR("Error allocating input device\n");
		return -ENOMEM;
	}

	monster_input_device->name = "MONSTER Keyboard";
	monster_input_device->phys = DRIVER_NAME "/input0";
	monster_input_device->id.bustype = BUS_HOST;
	monster_input_device->dev.parent = &monster_platform_device->dev;

	if (key_map != NULL) {
		err = sparse_keymap_setup(monster_input_device, key_map, NULL);
		if (err) {
			MONSTER_ERROR("Failed to setup sparse keymap\n");
			goto err_free_input_device;
		}
	}

	err = input_register_device(monster_input_device);
	if (unlikely(err)) {
		MONSTER_ERROR("Error registering input device\n");
		goto err_free_input_device;
	}

	return 0;

err_free_input_device:
	input_free_device(monster_input_device);

	return err;
}

struct platform_device *monster_keyboard_init_driver(struct monster_keyboard_driver *tk_driver)
{
	int err;
	struct platform_device *new_platform_device = NULL;

	MONSTER_DEBUG("init driver start\n");

	mutex_lock(&monster_keyboard_init_driver_lock);

	if (!IS_ERR_OR_NULL(monster_platform_device)) {
		// If already initialized, don't proceed
		MONSTER_DEBUG("platform device already initialized\n");
		goto init_driver_exit;
	} else {
		// Otherwise, attempt to initialize structures
		MONSTER_DEBUG("create platform bundle\n");
		new_platform_device = platform_create_bundle(
			tk_driver->platform_driver, tk_driver->probe, NULL, 0, NULL, 0);

		monster_platform_device = new_platform_device;

		if (IS_ERR_OR_NULL(monster_platform_device)) {
			// Normal case probe failed, no init
			goto init_driver_exit;
		}

		MONSTER_DEBUG("initialize input device\n");
		if (tk_driver->key_map != NULL) {
			err = monster_input_init(tk_driver->key_map);
			if (unlikely(err)) {
				MONSTER_ERROR("Could not register input device\n");
				tk_driver->input_device = NULL;
			} else {
				MONSTER_DEBUG("input device registered\n");
				tk_driver->input_device = monster_input_device;
			}
		}

		current_driver = tk_driver;
	}

init_driver_exit:
	mutex_unlock(&monster_keyboard_init_driver_lock);
	return new_platform_device;
}
EXPORT_SYMBOL(monster_keyboard_init_driver);

static void __exit monster_input_exit(void)
{
	if (unlikely(!monster_input_device)) {
		return;
	}

	input_unregister_device(monster_input_device);
	{
		monster_input_device = NULL;
	}
}

void monster_keyboard_remove_driver(struct monster_keyboard_driver *tk_driver)
{
	bool specified_driver_differ_from_used =
		tk_driver != NULL && 
		(
			strcmp(
				tk_driver->platform_driver->driver.name,
				current_driver->platform_driver->driver.name
			) != 0
		);

	if (specified_driver_differ_from_used)
		return;

	MONSTER_DEBUG("monster_input_exit()\n");
	monster_input_exit();
	MONSTER_DEBUG("platform_device_unregister()\n");
	if (!IS_ERR_OR_NULL(monster_platform_device)) {
		platform_device_unregister(monster_platform_device);
		monster_platform_device = NULL;
	}
	MONSTER_DEBUG("platform_driver_unregister()\n");
	if (!IS_ERR_OR_NULL(current_driver)) {
		platform_driver_unregister(current_driver->platform_driver);
		current_driver = NULL;
	}

}
EXPORT_SYMBOL(monster_keyboard_remove_driver);

static int __init monster_keyboard_init(void)
{
	MONSTER_INFO("module init\n");
	return 0;
}

static void __exit monster_keyboard_exit(void)
{
	MONSTER_INFO("module exit\n");

	if (monster_platform_device != NULL)
		monster_keyboard_remove_driver(NULL);
}

module_init(monster_keyboard_init);
module_exit(monster_keyboard_exit);
